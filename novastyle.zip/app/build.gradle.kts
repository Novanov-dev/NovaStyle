plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.novastyle.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.novastyle.app"
        minSdk = 26
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        create("nova") {
            storeFile = file("nova.jks")
            storePassword = "novastyle"
            keyAlias = "nova"
            keyPassword = "novastyle"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("nova") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
