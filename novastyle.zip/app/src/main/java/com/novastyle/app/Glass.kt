package com.novastyle.app

import android.graphics.*
import kotlin.math.cos
import kotlin.math.sin

class Theme(val name: String, val bg: IntArray, val orbs: IntArray)

object Glass {
    val themes = listOf(
        Theme("Azul metal",
            intArrayOf(0xFF030814.toInt(), 0xFF0B2A55.toInt(), 0xFF2F6DB8.toInt()),
            intArrayOf(0xFF74B3F5.toInt(), 0xFF3DB5FF.toInt(), 0xFFBFD9FF.toInt(), 0xFF7B93FF.toInt())),
        Theme("Aurora",
            intArrayOf(0xFF03110F.toInt(), 0xFF0A3B3A.toInt(), 0xFF1B5E7A.toInt()),
            intArrayOf(0xFF3EF2B0.toInt(), 0xFF38B6FF.toInt(), 0xFFA78BFA.toInt(), 0xFF7CF5D6.toInt())),
        Theme("Rosa",
            intArrayOf(0xFF140716.toInt(), 0xFF4A1650.toInt(), 0xFFB23A8F.toInt()),
            intArrayOf(0xFFFF8AD1.toInt(), 0xFFB794F6.toInt(), 0xFFFFC2E6.toInt(), 0xFF7CC3FF.toInt())),
        Theme("Grafito",
            intArrayOf(0xFF050505.toInt(), 0xFF14181F.toInt(), 0xFF2A3342.toInt()),
            intArrayOf(0xFFC8D4E6.toInt(), 0xFF8AA6C9.toInt(), 0xFFE8F2FF.toInt(), 0xFF5E7BA6.toInt()))
    )
}

class Orb(val x: Float, val y: Float, val r: Float, val sx: Float, val sy: Float, val ph: Float, val par: Float)

class Scene(val w: Float, val h: Float, th: Theme) {
    private fun al(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)
    private val bg = Paint().apply { shader = LinearGradient(0f, 0f, 0f, h, th.bg, floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP) }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x55FFFFFF; strokeWidth = w * 0.004f }
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xB0FFFFFF.toInt(); strokeWidth = w * 0.009f
    }
    private val sheenP = Paint().apply {
        shader = LinearGradient(0f, 0f, w, h * 0.35f, intArrayOf(0x00FFFFFF, 0x1CFFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }
    private val rnd = java.util.Random(7)
    private val orbs = List(8) { i ->
        Orb(rnd.nextFloat() * w, rnd.nextFloat() * h, w * (0.10f + rnd.nextFloat() * 0.17f),
            0.6f + rnd.nextFloat(), 0.5f + rnd.nextFloat(), rnd.nextFloat() * 6.28f, 0.3f + (i % 3) * 0.35f)
    }
    private val shaders = orbs.mapIndexed { i, o ->
        val c = th.orbs[i % th.orbs.size]
        RadialGradient(0f, 0f, o.r, intArrayOf(al(c, 0x10), al(c, 0x30), 0x80FFFFFF.toInt()), floatArrayOf(0f, 0.72f, 1f), Shader.TileMode.CLAMP)
    }
    private val rect = RectF()

    fun draw(c: Canvas, t: Float, ox: Float, oy: Float) {
        c.drawRect(0f, 0f, w, h, bg)
        orbs.forEachIndexed { i, o ->
            val x = o.x + sin(t * o.sx + o.ph) * w * 0.12f + ox * o.par * w * 0.10f
            val y = o.y + cos(t * o.sy + o.ph) * h * 0.06f + oy * o.par * h * 0.05f
            c.save(); c.translate(x, y)
            fill.shader = shaders[i]
            c.drawCircle(0f, 0f, o.r, fill)
            c.drawCircle(0f, 0f, o.r, ring)
            rect.set(-o.r * 0.78f, -o.r * 0.78f, o.r * 0.78f, o.r * 0.78f)
            c.drawArc(rect, 200f, 50f, false, shine)
            c.restore()
        }
        c.save()
        c.translate(((t * w * 0.10f) % (w * 2f)) - w, 0f)
        c.drawRect(0f, 0f, w, h, sheenP)
        c.restore()
    }
}
