package com.novastyle.app

import android.graphics.Canvas
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService

class GlassWallpaper : WallpaperService() {
    override fun onCreateEngine(): Engine = E()

    inner class E : Engine(), SensorEventListener {
        private val h = Handler(Looper.getMainLooper())
        private val run = Runnable { frame() }
        private var scene: Scene? = null
        private var idx = -1
        private var lw = 0
        private var lh = 0
        private var vis = false
        private var t = 0f
        private var last = SystemClock.uptimeMillis()
        private var ox = 0f
        private var oy = 0f
        private var tx = 0f
        private var ty = 0f

        private fun sm() = this@GlassWallpaper.getSystemService(SENSOR_SERVICE) as SensorManager

        override fun onVisibilityChanged(visible: Boolean) {
            vis = visible
            if (visible) {
                sm().getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm().registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
                last = SystemClock.uptimeMillis()
                frame()
            } else {
                sm().unregisterListener(this)
                h.removeCallbacks(run)
            }
        }

        override fun onDestroy() {
            vis = false
            h.removeCallbacks(run)
            sm().unregisterListener(this)
            super.onDestroy()
        }

        override fun onSensorChanged(e: SensorEvent) { tx = -e.values[0] / 9.8f; ty = e.values[1] / 9.8f }
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}

        private fun frame() {
            if (!vis) return
            val p = this@GlassWallpaper.getSharedPreferences("ns", MODE_PRIVATE)
            val sf = surfaceHolder.surfaceFrame
            val i = p.getInt("theme", 0)
            if (scene == null || i != idx || sf.width() != lw || sf.height() != lh) {
                idx = i; lw = sf.width(); lh = sf.height()
                scene = Scene(lw.toFloat(), lh.toFloat(), Glass.themes[i])
            }
            val now = SystemClock.uptimeMillis()
            t += (now - last) / 1000f * 0.6f * (p.getInt("speed", 5) / 5f)
            last = now
            val tilt = p.getBoolean("tilt", true)
            ox += (tx - ox) * 0.08f; oy += (ty - oy) * 0.08f
            var c: Canvas? = null
            try {
                c = surfaceHolder.lockHardwareCanvas()
                if (c != null) scene?.draw(c, t, if (tilt) ox else 0f, if (tilt) oy else 0f)
            } catch (e: Exception) {
            } finally {
                if (c != null) try { surfaceHolder.unlockCanvasAndPost(c) } catch (e: Exception) {}
            }
            h.removeCallbacks(run)
            h.postDelayed(run, 33)
        }
    }
}
