package com.novastyle.app

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.widget.*

class MetalBg(c: Context) : View(c) {
    private val p = Paint()
    private val s = Paint()
    private val o = Paint()
    private val cols = intArrayOf(0xFF040A15.toInt(), 0xFF0E2D57.toInt(), 0xFF2F6DB8.toInt(), 0xFF74B3F5.toInt(), 0xFF2F6DB8.toInt(), 0xFF0E2D57.toInt(), 0xFF040A15.toInt())
    private val sheen = intArrayOf(0x00FFFFFF, 0x00FFFFFF, 0x40FFFFFF, 0x00FFFFFF, 0x00FFFFFF)
    private val pos = floatArrayOf(0f, 0.35f, 0.5f, 0.65f, 1f)
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        o.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0x22000000, 0xBB000000.toInt(), Shader.TileMode.CLAMP)
    }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val t = (SystemClock.uptimeMillis() % 9000L) / 9000f
        val per = w * 1.6f
        p.shader = LinearGradient(t * per, 0f, t * per + per, 0f, cols, null, Shader.TileMode.REPEAT)
        cv.drawRect(0f, 0f, w, h, p)
        val per2 = w * 2.4f
        s.shader = LinearGradient(t * per2, 0f, t * per2 + per2, 0f, sheen, pos, Shader.TileMode.REPEAT)
        cv.drawRect(0f, 0f, w, h, s)
        cv.drawRect(0f, 0f, w, h, o)
        postInvalidateDelayed(40)
    }
}

class Preview(c: Context, private val prefs: SharedPreferences) : View(c) {
    private var sc: Scene? = null
    private var idx = -1
    private var lw = 0
    private var lh = 0
    private var t = 0f
    private var last = SystemClock.uptimeMillis()
    private val path = Path()
    override fun onDraw(cv: Canvas) {
        val w = width; val h = height
        val i = prefs.getInt("theme", 0)
        if (sc == null || i != idx || w != lw || h != lh) {
            idx = i; lw = w; lh = h; sc = Scene(w.toFloat(), h.toFloat(), Glass.themes[i])
        }
        val now = SystemClock.uptimeMillis()
        t += (now - last) / 1000f * 0.6f * (prefs.getInt("speed", 5) / 5f)
        last = now
        path.reset(); path.addRoundRect(0f, 0f, w.toFloat(), h.toFloat(), 40f, 40f, Path.Direction.CW)
        cv.clipPath(path)
        sc?.draw(cv, t, 0f, 0f)
        postInvalidateDelayed(33)
    }
}

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private val pals = mutableListOf<Button>()
    private val gray = 0xFF8AA6C9.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun tv(t: String, sz: Float, col: Int = 0xFFE8F2FF.toInt(), bold: Boolean = false) =
        TextView(this).apply { text = t; textSize = sz; setTextColor(col); if (bold) setTypeface(null, Typeface.BOLD) }

    private fun btnOf(label: String, f: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(Color.WHITE); textSize = 14f
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF2F86D8.toInt(), 0xFF1A56A3.toInt())).apply {
            cornerRadius = dp(12).toFloat(); setStroke(dp(1), 0xFF7CC3FF.toInt())
        }
        setOnClickListener { f() }
    }

    private fun card(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xCC0B1A30.toInt()); setStroke(dp(1), 0x555EAAFF) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        addView(tv(title, 16f, 0xFFCFE6FF.toInt(), true).apply { setPadding(0, 0, 0, dp(8)) })
    }

    @Suppress("DEPRECATION")
    private fun realSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(dm)
        return Pair(minOf(dm.widthPixels, dm.heightPixels), maxOf(dm.widthPixels, dm.heightPixels))
    }

    private fun palUi() {
        val cur = prefs.getInt("theme", 0)
        pals.forEachIndexed { i, b -> b.alpha = if (i == cur) 1f else 0.4f }
    }

    private fun setWp(b: Bitmap, flag: Int) {
        Thread {
            try {
                WallpaperManager.getInstance(this).setBitmap(b, null, true, flag)
                runOnUiThread { toast("Fondo aplicado") }
            } catch (e: Exception) {
                runOnUiThread { toast("No se pudo aplicar: ${e.message}") }
            }
        }.start()
    }

    private fun applyStatic(flag: Int) {
        val (w, h) = realSize()
        val th = Glass.themes[prefs.getInt("theme", 0)]
        Thread {
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Scene(w.toFloat(), h.toFloat(), th).draw(Canvas(bmp), 3f, 0f, 0f)
            runOnUiThread { setWp(bmp, flag) }
        }.start()
    }

    private fun applyLive() {
        val cn = ComponentName(this, GlassWallpaper::class.java)
        try {
            startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, cn))
        } catch (e: Exception) {
            try { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }
            catch (e2: Exception) { toast("Abre Fondos de pantalla, Fondos animados, y elige NovaStyle Glass") }
        }
    }

    private fun pick(b: Bitmap) {
        AlertDialog.Builder(this).setTitle("Usar foto en")
            .setItems(arrayOf("Pantalla de inicio", "Pantalla de bloqueo", "Las dos")) { _, i ->
                setWp(b, when (i) {
                    0 -> WallpaperManager.FLAG_SYSTEM
                    1 -> WallpaperManager.FLAG_LOCK
                    else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                })
            }.show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 7 || res != RESULT_OK) return
        val uri = data?.data ?: return
        val (sw, sh) = realSize()
        Thread {
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                var s = 1
                while (o.outWidth / (s * 2) >= sw && o.outHeight / (s * 2) >= sh) s *= 2
                val bmp = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
                }
                if (bmp != null) runOnUiThread { pick(bmp) }
            } catch (e: Exception) {
                runOnUiThread { toast("No pude abrir esa imagen") }
            }
        }.start()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("ns", MODE_PRIVATE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(40), dp(14), dp(30)) }

        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(14)) }
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo)
            layoutParams = LinearLayout.LayoutParams(dp(84), dp(84)).apply { rightMargin = dp(14) }
        })
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.addView(tv("NovaStyle", 28f, bold = true)); ht.addView(tv("Personaliza tu celular", 13f, gray))
        head.addView(ht); col.addView(head)

        val cp = card("Vista previa")
        cp.addView(Preview(this, prefs).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(220)) })
        col.addView(cp)

        val cs = card("Estilo")
        val row = LinearLayout(this)
        Glass.themes.forEachIndexed { i, th ->
            val bt = btnOf(th.name) { prefs.edit().putInt("theme", i).apply(); palUi() }
            bt.textSize = 12f
            bt.layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) }
            pals.add(bt); row.addView(bt)
        }
        cs.addView(row); palUi()
        cs.addView(tv("Velocidad del movimiento", 14f, bold = true).apply { setPadding(0, dp(12), 0, 0) })
        cs.addView(SeekBar(this).apply {
            max = 9; progress = prefs.getInt("speed", 5) - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { prefs.edit().putInt("speed", p + 1).apply() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        val tr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
        tr.addView(tv("Moverse al inclinar", 14f, bold = true).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        tr.addView(Switch(this).apply {
            isChecked = prefs.getBoolean("tilt", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("tilt", c).apply() }
        })
        cs.addView(tr)
        cs.addView(tv("Las burbujas de cristal se desplazan cuando inclinas el celular.", 12f, gray))
        col.addView(cs)

        val c1 = card("Fondo animado")
        c1.addView(tv("Se aplica desde el selector del sistema, donde eliges si va en inicio, bloqueo o ambos.", 12f, gray))
        c1.addView(btnOf("Aplicar fondo animado") { applyLive() })
        col.addView(c1)

        val c2 = card("Fondo fijo con este estilo")
        c2.addView(tv("Guarda una imagen del diseño actual como fondo normal, sin movimiento y sin gastar batería.", 12f, gray))
        c2.addView(btnOf("En pantalla de inicio") { applyStatic(WallpaperManager.FLAG_SYSTEM) })
        c2.addView(btnOf("En pantalla de bloqueo") { applyStatic(WallpaperManager.FLAG_LOCK) })
        c2.addView(btnOf("En las dos") { applyStatic(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK) })
        col.addView(c2)

        val c3 = card("Tu propia foto")
        c3.addView(tv("Elige una imagen de tu galería y ponla de fondo.", 12f, gray))
        c3.addView(btnOf("Elegir foto") {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7)
        })
        col.addView(c3)

        val c4 = card("Iconos")
        c4.addView(tv("El paquete de iconos de cristal viene en el siguiente paso.", 12f, gray))
        col.addView(c4)

        setContentView(FrameLayout(this).apply {
            addView(MetalBg(this@MainActivity))
            addView(ScrollView(this@MainActivity).apply { addView(col) })
        })
    }
}
